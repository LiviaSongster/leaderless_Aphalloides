#!/bin/bash
#########################################################################################
#FUNCTION
#This script will take prior information about what MSDINs look like and use them to find introns and output all possible intron combinations at a #given locus. The real goal of this script is to determine where the end of MSDINs may be. Both canonical and non-canonical introns will be considered. 
#
#This script is designed to find the introns in the putative MSDIN sequences. The sequences that do not have putative introns in them are thus #eliminated as all known MSDINs have conserved intron structure. The MSDIN sequences where putative introns can be found will be processed and placed 
#into a file called “where_is_stop” as, with the intron structure, the script can look for where a putative stop codon would be.
#all of the input sequences will be translated into protein and placed into a file called “all_unprocessed_prots.fasta”
#
#REQUIRED PROGRAMS
#This script assumes you have EMBOSS installed and in path
#
#REQUIRED INPUTS
#script assumes output of previous script was output correctly and into the default folder
#
#MISC
#this script allows: you to set the MSDIN leader/core/follower length ranges as well as the intron length range (defaults are already in place)
#
#OUTPUT
#all of the input sequences that did not have putative introns will be placed into a file called “unprocessed_prots.fasta”
#these could be used to look for pseudogenized MSDINs and or to look for MSDINs where current intron parameters erroneously eliminate/manipulate #sequences.
#all results will be placed into a folder called “preprocessed_msdins”
#########################################################################################
#
#Variables that may need defining ----------------------------------------------------------------
#following lengths are in AA
Leader_length_range="0-0"
#note there's a line below that says 6 is minimum... not sure if that's real -- just revisiting this script much later.
core_length_range="6-10"
follower_length_range="15-19"
#following length in bp
intron_length_range="52-58"
gene_file_path="./deduped_and_gene/"
#
#the following variable defines how many codons back from the end of the follower to being looking for intron end.
follower_codon_intron_end="4"
#
#runmodes = "proline_guided" (requires proline at end of core – fastest and what was used in the manuscript) "allow_no_proline" (if core seqs don’t #have proline at end then test all #possible core ends – can be much slower – if prolines exist it will default to looking at them) "always_check" #(looks for all possible MSDINs even if #prolines are present in a position that suggests the end of core – #slowest option) 
runmode="always_check"
#--------------------------------------------------------------------------------------------------------
#
#
cat "$gene_file_path"*leaderless_gene_file | awk '{print $1,toupper($2),$3}' > gene_file 
#
Leader_start=`echo $Leader_length_range | sed 's/-/ /' | awk '{print $1}'`
Leader_end=`echo $Leader_length_range | sed 's/-/ /' | awk '{print $2}'`
#
Length_of_file=`cat gene_file | wc -l | sed 's/ //g' `
Length_of_file_multiplier=`seq $Leader_start $Leader_end | wc -l | sed 's/ //g'`
Final_length_of_process=`echo $Length_of_file $Length_of_file_multiplier | awk '{print $1*$2}'`
#
COUNTER="1"
#
rm where_is_stop
#
for Leader_length in $(seq $Leader_start $Leader_end);do
#
#we can ignore anything before this range hence removing it over and over below.. +1 because it starts one after the leader
Leader_nuc_len=`echo $Leader_length | awk '{print $1*3}'`
Leader_nuc_len_plus_one=`echo $Leader_length | awk '{print ($1*3)+1}'`
Def_core=`echo $core_length_range | sed 's/-/ /' | awk -v leader=$Leader_nuc_len '{print ($1-1)*3+leader}'`
start_core=`echo $core_length_range | sed 's/-/ /' | awk  -v leader_plus_one=$Leader_nuc_len_plus_one '{print ($1-1)*3+leader_plus_one}'`
end_core=`echo $core_length_range | sed 's/-/ /' | awk  -v leader=$Leader_nuc_len '{print $2*3+leader}'`
#adding one back in seems to deal with it cutting the core region short by one.. again may have to do with how "cut" is inclusive or not.
core_range=` echo $end_core $start_core | sed 's/-/ /' | awk '{print $1-$2+1}'`
maybe_proline_range=`echo $core_range $Def_core | awk '{print $2-$1}'`
Def_coreAA=`echo $core_length_range | sed 's/-.*/ /' | awk '{print ($1-1)}'`
#
#according to pulman the intron always occurs in the fourth-to-last amino acid (including stop) so that's where we'll start looking..
start_follower=`echo $follower_length_range | sed 's/-/ /' | awk -v intron_end_codon="$follower_codon_intron_end" '{print ($1-intron_end_codon)*3}'`
end_follower=`echo $follower_length_range | sed 's/-/ /' | awk '{print $2*3}'`
#
intron_low=`echo $intron_length_range | sed 's/-/ /' | awk '{print $1}'`
intron_high=`echo $intron_length_range | sed 's/-/ /' | awk '{print $2}'`
#
echo $Leader_length $start_core $end_core $core_range
echo $Leader_length $start_follower $end_follower
#
#Name of file is just transmitted to resulting maps and is not used here.
while read gene_name sequence FILE;do
#
echo ----------------------------------------------------------------
echo starting line $COUNTER of $Final_length_of_process
echo ----------------------------------------------------------------
#
COUNTER=$[COUNTER + 1]
#
LEADER_SEQUENCE=""
DEFINITELY_CORE_SEQUENCE=`echo $sequence| cut -c"$Leader_nuc_len_plus_one"-"$Def_core" `
MAYBE_CORE_SEQUENCE=`echo $sequence| cut -c"$start_core"-"$end_core" `
#
#the above assumes that the length of the core is at least 6AA without the P so the following will look for the end of the core at AA 7-10
#	
#remove stuff before one would expect to find a P in the core range and then look for Ps afterwards. Mark these as possible end of core.
#output indicates which codon in the range is a P and COULD be the end of the core. If there are multiple it should iterate through them…
#this should be cutting it in a way that the ‘definitely core’ is not included – this is based off of the core length defined above.
#
if [[ $runmode =~ (proline_guided|allow_no_proline) ]];then
echo $sequence| cut -c"$start_core"-9999 | cut -c1-"$core_range" |sed $'s/.\{3\}/&\\\n/g' | grep -n '\(CCT\|CCC\|CCA\|CCG\)' | sed 's/:.*//' >  possible_end_of_core
fi
#
#if end of core does not have a proline then just look at the last few codons in the possible core region
#
if [[ $runmode =~ (allow_no_proline|always_check) ]];then
Possible_end_of_core_check=`cat possible_end_of_core | grep . | wc -l | sed 's/ //g' `
if [ $Possible_end_of_core_check -eq 0 ];then
echo no proline found in range
#
Leader_minAA=`echo $Leader_length_range | sed 's/-.*//'`
Core_minAA=` echo $core_length_range | sed 's/-.*//' `
Leader_maxAA=`echo $Leader_length_range | sed 's/.*-//'`
Core_maxAA=` echo $core_length_range | sed 's/.*-//' `
#
#
#
end_coresearch_manual=`echo $Def_coreAA $Core_maxAA | awk ' {print $2-$1}' `
for x in $( eval echo {1..$end_coresearch_manual} );do echo $x ;done >possible_end_of_core
else
echo proline found
fi
fi
#
while read end_core_proline_codon;do
#now we start looking from the proline to look for intron start/end cites
#
#
#at this point counting is done relative to the leader+def core
Earliest_intron_start=` echo $end_core_proline_codon| awk -v start_follower="$start_follower" -v core="$start_core" '{print $1*3+start_follower+core+1}'`
Latest_intron_start=` echo $end_core_proline_codon| awk -v end_follower="$end_follower" -v core="$start_core" '{print $1*3+end_follower+core}'`
#
#look for potential start of the intron
MAYBE_INTRON_START=` echo $sequence | cut -c"$Earliest_intron_start""-""$Latest_intron_start" `
#
echo $sequence | cut -c"$Earliest_intron_start"-"$Latest_intron_start" |sed $'s/GT/&\\\n/g' | grep GT| awk '{ print $1, length-2 }'> possible_intron_start
echo $sequence | cut -c"$Earliest_intron_start"-"$Latest_intron_start" |sed $'s/GC/&\\\n/g' | grep GC| awk '{ print $1, length-2 }'> non_canon_possible_intron_start
#
#
Current_location="0"
Loop="0"
while read ignore_sequence possible_intron_start;do
#
if [ $Loop -gt 0 ];then
Current_location=$[ Current_location + 2 + possible_intron_start ]
else
Current_location=$[ Current_location + possible_intron_start ]
fi
#
#
Earliest_intron_end=`echo 0 | awk -v start="$Earliest_intron_start" -v intron_low="$intron_low" '{print $1+start+intron_low}'`
Latest_intron_end=` echo 0 | awk -v start="$Latest_intron_start"  -v intron_high="$intron_high" '{print $1+start+intron_high}'`
#
MAYBE_INTRON_END=` echo $sequence | cut -c"$Earliest_intron_end"-"$Latest_intron_end"  `
#
#
echo $sequence| cut -c"$Earliest_intron_end"-"$Latest_intron_end" | grep 'AG' | wc -l | sed 's/ //g'> possible_intron_end_codons
#
#determine if that are ANY GTs that could end the intron and if so then move forward
Any_ends=`cat possible_intron_end_codons`
#
Loop=$[ Loop + 1]
#
if [ $Any_ends -gt 0 ];then
#
echo $sequence | cut -c"$Earliest_intron_end"-"$Latest_intron_end"  | sed $'s/AG/AG\\\n/g' | grep AG | awk '{ print length }' | tr '\n' ' '| awk '{for (i = 1; i <= NF; ++i) {printf("%d ", s += $i);}   printf("\n");}' | tr ' ' '\n' | grep . > possible_ends
#
#loop through accounting for the length of the GT and where the new reading frame would start… -- still haven't vetted these numbers for current frame
#
#
while read end;do
current_frame=`echo $Earliest_intron_end | awk -v value=$end '{print $1+value+4"-"$1+value+8+1}'`
#
current_frame_codon=`echo $sequence | cut -c"$current_frame" | grep '\(TAA\|TAG\|TGA\)'| sed 's/ //g'| wc -l`
end_seq=` echo $sequence | cut -c"$current_frame"`
#
MAYBE_STOP=` echo $sequence | cut -c"$current_frame" `
#
Last_bp_of_exon1=`echo $Earliest_intron_start | awk -v current=$Current_location '{print $1+current-1}'`
Start_of_exon2=`echo "$Earliest_intron_end"| awk -v end=$end '{print $1+end}'`
End_of_exon2=`echo $current_frame | sed 's/-/ /'| awk '{print $2}'`
#
SEQUENCE_AFTER_DEF_CORE=`echo $sequence | cut -c"$start_core"-"$Last_bp_of_exon1"`
SEQUENCE_AFTER_INTRON=`echo $sequence | cut -c"$Start_of_exon2"-"$End_of_exon2"`
#
echo $possible_intron_start $start_core $start_follower $end_core_proline_codon $Earliest_intron_start $Latest_intron_start "$Earliest_intron_end" "$Latest_intron_end" $Earliest_intron_start $Last_bp_of_exon1 $Start_of_exon2 $End_of_exon2 $end_core $core_range
#
CDS=`echo "$LEADER_SEQUENCE""$DEFINITELY_CORE_SEQUENCE""$SEQUENCE_AFTER_DEF_CORE""$SEQUENCE_AFTER_INTRON"`
#
echo ">really_dumb_that_transeq_needs_header" > temp_seq
echo $CDS >> temp_seq
transeq -sequence temp_seq -outseq temp_out -sformat pearson 2> silencing_transeq_just_saying_it_has_translated_stuff
rm silencing_transeq_just_saying_it_has_translated_stuff
#
cat temp_out| sed '/^>/ s/$/zzz/' |tr -d '\n' | sed $'s/zzz/\\\n/g'  | sed $'s/>/\\\n>/g' | grep . > ugh
mv ugh temp_out
#
PROTEIN=`cat temp_out | tail -1`
rm temp_seq temp_out
#
echo "$gene_name"stop_search_"$end_core_proline_codon"_"$Current_location"_"$end" $current_frame $Last_bp_of_exon1 $Start_of_exon2 $End_of_exon2 $Leader_length $Def_core $current_frame_codon $end_seq $LEADER_SEQUENCE $DEFINITELY_CORE_SEQUENCE $MAYBE_CORE_SEQUENCE $MAYBE_INTRON_START $MAYBE_INTRON_END $MAYBE_STOP $CDS $PROTEIN  $FILE
#
done < possible_ends >> where_is_stop
#
echo Current output DOES include stop in range
#
else
echo Current output DOES NOT include stop in range
fi
#
#this will be needed to shift us forward from the last possible start location.. this is mostly for intron searching
#
done < possible_intron_start
#
#
#
#
#
#
#The following is the same as above but it will process non-canonical introns
Current_location="0"
Loop="0"
while read ignore_sequence possible_intron_start;do
#
if [ $Loop -gt 0 ];then
Current_location=$[ Current_location + 2 + possible_intron_start ]
else
Current_location=$[ Current_location + possible_intron_start ]
fi
#
#
Earliest_intron_end=`echo 0 | awk -v start="$Earliest_intron_start" -v intron_low="$intron_low" '{print $1+start+intron_low}'`
Latest_intron_end=` echo 0 | awk -v start="$Latest_intron_start"  -v intron_high="$intron_high" '{print $1+start+intron_high}'`
#
MAYBE_INTRON_END=` echo $sequence | cut -c"$Earliest_intron_end"-"$Latest_intron_end"  `
#
#
echo $sequence| cut -c"$Earliest_intron_end"-"$Latest_intron_end" | grep 'AG' | wc -l | sed 's/ //g'> possible_intron_end_codons
#
#determine if that are ANY AGs that could end the intron and if so then move forward
Any_ends=`cat possible_intron_end_codons`
#
Loop=$[ Loop + 1]
#
if [ $Any_ends -gt 0 ];then
#
echo $sequence | cut -c"$Earliest_intron_end"-"$Latest_intron_end"  | sed $'s/AG/AG\\\n/g' | grep AG | awk '{ print length }' | tr '\n' ' '| awk '{for (i = 1; i <= NF; ++i) {printf("%d ", s += $i);}   printf("\n");}' | tr ' ' '\n' | grep . > possible_ends
#
#loop through accounting for the length of the AG and where the new reading frame would start… -- still  aven't vetted these numbers for current frame
#
#
while read end;do
current_frame=`echo $Earliest_intron_end | awk -v value=$end '{print $1+value+4"-"$1+value+8+1}'`
#
current_frame_codon=`echo $sequence | cut -c"$current_frame" | grep '\(TAA\|TAG\|TGA\)'| sed 's/ //g'| wc -l`
end_seq=` echo $sequence | cut -c"$current_frame"`
#
MAYBE_STOP=` echo $sequence | cut -c"$current_frame" `
#
Last_bp_of_exon1=`echo $Earliest_intron_start | awk -v current=$Current_location '{print $1+current-1}'`
Start_of_exon2=`echo "$Earliest_intron_end"| awk -v end=$end '{print $1+end}'`
End_of_exon2=`echo $current_frame | sed 's/-/ /'| awk '{print $2}'`
#
SEQUENCE_AFTER_DEF_CORE=`echo $sequence | cut -c"$start_core"-"$Last_bp_of_exon1"`
SEQUENCE_AFTER_INTRON=`echo $sequence | cut -c"$Start_of_exon2"-"$End_of_exon2"`
#
echo $possible_intron_start $start_core $start_follower $end_core_proline_codon $Earliest_intron_start $Latest_intron_start "$Earliest_intron_end" "$Latest_intron_end" $Earliest_intron_start $Last_bp_of_exon1 $Start_of_exon2 $End_of_exon2 $start_core
#
CDS=`echo "$LEADER_SEQUENCE""$DEFINITELY_CORE_SEQUENCE""$SEQUENCE_AFTER_DEF_CORE""$SEQUENCE_AFTER_INTRON"`
#
echo ">really_dumb_that_transeq_needs_header" > temp_seq
echo $CDS >> temp_seq
transeq -sequence temp_seq -outseq temp_out -sformat pearson 2> silencing_transeq_just_saying_it_has_translated_stuff
rm silencing_transeq_just_saying_it_has_translated_stuff
#
cat temp_out| sed '/^>/ s/$/zzz/' |tr -d '\n' | sed $'s/zzz/\\\n/g'  | sed $'s/>/\\\n>/g' | grep . > ugh
mv ugh temp_out
#
PROTEIN=`cat temp_out | tail -1`
rm temp_seq temp_out
#
echo "$gene_name"stop_search_"$end_core_proline_codon"_"NC""$Current_location"_"$end" $current_frame $Last_bp_of_exon1 $Start_of_exon2 $End_of_exon2 $Leader_length $Def_core $current_frame_codon $end_seq $LEADER_SEQUENCE $DEFINITELY_CORE_SEQUENCE $MAYBE_CORE_SEQUENCE $MAYBE_INTRON_START $MAYBE_INTRON_END $MAYBE_STOP $CDS $PROTEIN $FILE
#
done < possible_ends >> where_is_stop
#
echo Current output DOES include stop in range
#
else
echo Current output DOES NOT include stop in range
fi
#
#this will be needed to shift us forward from the last possible start location.. this is mostly for intron searching
#
done < non_canon_possible_intron_start
#
done < possible_end_of_core
#
rm possible_end_of_core
#
done < gene_file
done
#
cat gene_file | awk '{print $1,$2}'| sed 's/>//'| sed 's/^/>/' | tr '\t' '\n'| tr ' ' '\n' > all_unprocessed_cds
transeq -sequence all_unprocessed_cds -outseq all_unprocessed_prots.fasta -sformat pearson 2> silencing_transeq_just_saying_it_has_translated_stuff
rm silencing_transeq_just_saying_it_has_translated_stuff
#
cat all_unprocessed_prots.fasta | sed '/^>/ s/$/zzz/' |tr -d '\n' | sed $'s/zzz/\\\n/g'  | sed $'s/>/\\\n>/g' | grep . > ugh
mv ugh all_unprocessed_prots.fasta
#
rm all_unprocessed_cds possible_ends possible_intron_end_codons possible_intron_start possible_end_of_core non_canon_possible_intron_start possible_intron_codons possible_intron_start_codons
#
cat where_is_stop | grep '>' | sort -u > temp
mv temp where_is_stop
#
#get list of all processed/unprocessed hits
awk '{print $1}' where_is_stop | sed 's/stop_search.*//'|sort -u > processed_hits
awk '{print $1}' gene_file |sort -u >all_hits
cat all_hits processed_hits | sort | uniq -u > unprocessed_hits
#
awk 'NR==FNR{c[$1]++;next};c[$1] > 0' unprocessed_hits gene_file | awk '{print $1"\n"$2}' > unprocessed_genes.fasta
transeq -sequence unprocessed_genes.fasta -outseq temp_out -sformat pearson 2> silencing_transeq_just_saying_it_has_translated_stuff
rm silencing_transeq_just_saying_it_has_translated_stuff
#
cat temp_out| sed '/^>/ s/$/zzz/' |tr -d '\n' | sed $'s/zzz/\\\n/g'  | sed $'s/>/\\\n>/g' | grep . > ugh
mv ugh unprocessed_prots.fasta
#
rm unprocessed_genes.fasta processed_hits all_hits unprocessed_hits
#
mkdir preprocessed_msdins
mv where_is_stop ./preprocessed_msdins/
mv unprocessed_prots.fasta ./preprocessed_msdins/
mv all_unprocessed_prots.fasta ./preprocessed_msdins/
#
rm gene_file
