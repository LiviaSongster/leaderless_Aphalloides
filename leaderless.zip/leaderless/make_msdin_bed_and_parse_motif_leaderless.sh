#!/bin/bash
#########################################################################################
#FUNCTION
#This script will take the processed output of msdin_motif_process.sh – “where_is_stop” and will create a bed file for the entire msdin (including the #identified intron)while also extracting the leader, core and follower sequences. note that finalized beds for best sequences are generated later.
#
#the script will first filter the output of where_is_stop to include only MSDIN sequences that actually end in a ‘stop’. 
#It will then filter sequences to include only those with a single stop codon
#
#REQUIRED INPUT
#script assumes output of previous script was output correctly and into the default folder
#
#MISC
#I have had a little trouble getting different programs to interpret bed files the same way, some seem to be inclusive at both ends of a bed entry #while others are not thus, depending on what downstream application you’re using this for please confirm that the end of bed entries are not off by #+/- 1 – this should work correctly for programs used here.
#########################################################################################
#
#Variables that may need defining ----------------------------------------------------------------
Path_to_deduped="./deduped_and_gene/"
Path_to_where_is_stop="./preprocessed_msdins/"
# ------------------------------------------------------------------------------------------------------
#
#filter out sequences based ending in a stops/having too many stops.
cat "$Path_to_where_is_stop""where_is_stop" | grep '\* ' | awk '{print $1,$16,$17}' | sed 's/stop_search/ stop_search/' | awk -F'\*' '{print $0,NF-1}' | awk -F'_NC' '{print $0,NF-1}' | awk '$5=="1" {print}' | sort -k4,4| sed 's/>//' > processed_best_msdin
#
Number_of_msdins_to_process=`cat processed_best_msdin | wc -l | sed 's/ //g'`
COUNTER="1"
#
rm parsed_best_msdin processed_best_msdin.bed
while read old_name stop_search seq file scores;do
echo beginning to process msdin $COUNTER of $Number_of_msdins_to_process named: "$file" $old_name "prot"
#
#lets start by processing the protein into its constituents
#
Leader_end=` grep $old_name "$Path_to_where_is_stop"where_is_stop  | grep -w $stop_search | awk -v seq="$seq" '$16==seq {print}'|grep $file | awk '{print $6}'`
Core_start=`echo $Leader_end | awk '{print $1+1}'`
Core_end_proline=`echo $stop_search| sed 's/stop_search_//' | sed 's/_.*//'`
Core_end=` grep $old_name "$Path_to_where_is_stop"where_is_stop  | grep -w $stop_search | awk -v seq="$seq" '$16==seq {print}'|grep $file| awk -v leader=$Leader_end -v end_proline=$Core_end_proline '{print ($7/3)+end_proline}'`
Follower_start=`echo $Core_end | awk '{print $1+1}'`
#
#leaderless
#Leader=`echo $seq | cut -c1-"$Leader_end"`
Core=`echo $seq | cut -c"$Core_start"-"$Core_end"`
Follower=` echo $seq | cut -c"$Follower_start"-9999`
#
#echo $seq $Leader_end $Core_end_proline $Core_end
echo "$file" "PROT" $old_name"_z_""$stop_search""_x_" $Leader $Core $Follower $seq >> parsed_best_msdin
#
#
#Okay now lets generate the cds for these…
echo beginning to process msdin $COUNTER of $Number_of_msdins_to_process named: "$file" $old_name "nuc"
#
Full_cds=` grep $old_name "$Path_to_where_is_stop"where_is_stop  | grep -w $stop_search | awk -v seq="$seq" '$16==seq {print}'|grep $file | awk '{print $15}'`
#
Nuc_intron_start=` echo $Core_end `
Nuc_leader_end=`echo $Leader_end| awk '{print ($1*3)}'`
Nuc_core_start=`echo $Nuc_leader_end | awk '{print $1+1}'`
Nuc_core_end=`echo $Core_end | awk '{print $1*3}'`
Nuc_follower_start=`echo $Nuc_core_end | awk '{print $1+1}'`
#
#leaderless
#Nuc_leader=` echo $Full_cds | cut -c1-"$Nuc_leader_end"`
Nuc_core=` echo $Full_cds | cut -c"$Nuc_core_start"-"$Nuc_core_end"`
Nuc_follower=` echo $Full_cds | cut -c"$Nuc_follower_start"-9999`
#
#echo $Full_cds $nuc_leader_end $Nuc_core_start $Nuc_core_end $Nuc_follower_start
echo "$file" "NUC" $old_name"_z_""$stop_search""_x_" $Nuc_leader $Nuc_core $Nuc_follower $Full_cds >> parsed_best_msdin
#
#okay now lets generate a bed file for them…
echo beginning to process msdin $COUNTER of $Number_of_msdins_to_process named: "$file" $old_name "bed"
COUNTER=$[COUNTER + 1]
#
Chrm=`grep $old_name "$Path_to_deduped""$file" | awk '{print $1}'`
Orient=`grep $old_name "$Path_to_deduped""$file"| awk '{print $6}'`
Og_low=`grep $old_name "$Path_to_deduped""$file"| awk '{print $2}'`
Og_high=`grep $old_name "$Path_to_deduped""$file"| awk '{print $3}'`
#
End_exon1=` grep $old_name "$Path_to_where_is_stop"where_is_stop | grep -w $stop_search | awk -v seq="$seq" '$16==seq {print}'|grep $file | awk '{print $3+1}'`
Start_intron=`echo $End_exon1 | awk '{print $1+1}'`
#DELETED A PLUS ONE at end of following line for $4 initial testing seems to suggest this is correct
End_intron=` grep $old_name "$Path_to_where_is_stop"where_is_stop | grep -w $stop_search | awk -v seq="$seq" '$16==seq {print}'|grep $file | awk '{print $4}'`
#
Length=` echo $Full_cds | wc -c | sed 's/ //g' `
Exon_remaining=`echo $End_exon1 $Length | awk '{print $2-$1}'`
End_exon2=`echo $End_intron $Exon_remaining| awk '{print $1+$2}'`
#
echo $Chrm $Og_low $Og_high "exon1""_z_""$old_name""__""$file""_z_""$stop_search""_x_" "NA" $Orient |awk -v end=$End_exon1 '{if ($6=="+") {print $1"\t"$2+1"\t"$2+end"\t"$4"\t"$5"\t"$6} else {print $1"\t"$3-end"\t"$3-1"\t"$4"\t"$5"\t"$6}}' > temp.bed
#
echo $Chrm $Og_low $Og_high "intron1""_z_""$old_name""__""$file""_z_""$stop_search""_x_"  "NA" $Orient |awk -v start=$Start_intron -v end=$End_intron '{if ($6=="+") {print $1"\t"$2+start-1"\t"$2+end"\t"$4"\t"$5"\t"$6} else {print $1"\t"$3-end"\t"$3-start+1"\t"$4"\t"$5"\t"$6}}' >> temp.bed
#
#DELETED A PLUS ONE at end of reverse end that initial testing supports
echo $Chrm $Og_low $Og_high "exon2""_z_""$old_name""__""$file""_z_""$stop_search""_x_"  "NA" $Orient |awk -v start=$End_intron -v end=$End_exon2 '{if ($6=="+") {print $1"\t"$2+start"\t"$2+end"\t"$4"\t"$5"\t"$6} else {print $1"\t"$3-end"\t"$3-start"\t"$4"\t"$5"\t"$6}}' >> temp.bed
#
cat temp.bed >> processed_best_msdin.bed
rm temp.bed
done < processed_best_msdin
#
mkdir processed_msdin
mv processed_best_msdin* ./processed_msdin/
mv parsed_best_msdin ./processed_msdin/



