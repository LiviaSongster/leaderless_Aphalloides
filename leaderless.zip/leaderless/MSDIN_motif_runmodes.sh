#!/bin/bash
#########################################################################################
#FUNCTION
#
#This script uses motifs of MSDIN leader and CVGDD follower sequence to identify where in the blast-hits transmitted from last script the MSDIN may be
#exactly. Mast filters to e-values less than 100 which is a lenient cutoff. The script also determines the orientation of the hit and requires  
# that THE MSDIN hit precedes the CVGDD hit in the sequence. Requires that sequence start with ATG/M. While the script could still output a sequence 
#lacking a CVGDD hit, it will not output one without an MSDIN hit.
#
#REQUIRED PROGRAMS
# the script assumes that you have the MEME suit installed and needs a PATH to mast – also defined at the top of the script below.
#if MEME suit has already been added to PATH, then set mast path variable to ""
#script assumes you have Bedtools installed and in path.
#
#REQUIRED FILES
#This script assumes: you have pre-built a set of motif files for the MSDIN leader sequence and for the CVGDDD beginning of the follower sequence
#these two should both be put together into a file that is designated in the “path_to_motif_file”  variable below. Note that the order of motifs in the 
#file matters a lot as if motif 2 occurs before motif 1 then it ignores it. Note that the files used in our publication are included in the example #dataset
#
#REQUIRED FORMATTING OF INPUT
#script assumes output of previous script was output correctly and into the default folder
#the script again assumes that genomes are named “name in name list”.fna.gz and are present in a folder ./genomes/ although the input folder can be #modified at the top of the script.
#
#This script requires: a name of accessions like the previous script – single column and called “name_list”
#script requires definition of path to “maybe_prot” files generated in previous script (msdin_blast_new.sh) –  should be fine if you have not changed the default.
#
#MISC
#script will self-tidy and while I’ve tried to avoid this, you shouldn’t store any important files in the run directory as they could be remove. All #files that need to be brought in need their paths specified at the top of the script
#
#########################################################################################
#
#Variables that may need defining ----------------------------------------------------------------
Genome_folder_path="./genomes/"
Path_to_mast="/Users/mdrott/Desktop/Projects/Phalloides_leaderless/bin/meme-5.5.6/src/"
Path_to_motif_file="./final_motif.txt"
Path_to_maybe_prot="./putative_msdin_prots/"
#
#note this script is only set up to run in leaderless mode for now. pleaes use MSDIN_motif.sh for leadered searches.
runmode="allow_leaderless"
#if allowing leaderless, do following
core_length_range="6-10"
#which will auto populate this:
core_min_length=`echo $core_length_range | awk -F'-' '{print $1}'`
core_max_length=`echo $core_length_range | awk -F'-' '{print $2}'`
#--------------------------------------------------------------------------------------------------------------------------------
#
mkdir deduped_and_gene
#
while read -r iso; do
#
#
Current_time=`date +"%T"`
echo ===============================================
echo Beginning msdin_motif of $iso at $Current_time
echo ===============================================
#
#
#preprocess genome to make naming scheme appropriate for downstream use…
#bring in and unzip genome
cp "$Genome_folder_path""$iso".fna.gz .
gunzip "$iso".fna.gz 
#
#for consistency with above parts of the pipeline – remove period that break first script
Working_iso=`echo $iso | sed 's/\./_/g'`
#
#rename chromosomes and add chrm length to them…
#first rename file to have the header iso_chrm#
cat "$iso".fna | awk -v iso="$Working_iso" -v chrm="0" '{if ($0 ~ ">") {print ">"iso"_chrm"++chrm} else {print}}' >temp.fna 
#then create afile of chrm lengths to use in renaming where length is added to name
cat temp.fna | awk '$0 ~ ">" {if (NR > 1) {print c;} c=0;printf substr($0,2,100) "\t"; } $0 !~ ">" {c+=length($0);} END { print c; }' | awk '{print ">"$1,">"$1"_""length_"$2}' > temp_chrm_lengths
#
#add lengths to name
awk 'FNR==NR{a[$1]=$2;next} {if ($1 in a){$1=a[$1]}; print $0}' temp_chrm_lengths temp.fna > genome_with_lengths
mv genome_with_lengths "$iso".fna
rm temp.fna temp_chrm_lengths
#
samtools faidx "$iso".fna
#
cp "$Path_to_maybe_prot""$iso""_maybe_prot.fasta" .
#
#run mast motif search
"$Path_to_mast"mast "$Path_to_motif_file" "$iso""_maybe_prot.fasta" -oc mast_output -ev 100
grep 'sequence db=' ./mast_output/mast.xml | sed 's/.*name=\"//' | sed 's/\".*//'| grep . > temp_names
#
while read;do
pval=`sed -n -e "/$REPLY/,/\/sequence/ p" ./mast_output/mast.xml | grep combined_pvalue | sed 's/.*pvalue=\"//' | sed 's/\".*//'`
eval=`sed -n -e "/$REPLY/,/\/sequence/ p" ./mast_output/mast.xml | grep combined_pvalue | sed 's/.*evalue=\"//' | sed 's/\".*//'`
#
Motif1_pos=`sed -n -e "/$REPLY/,/\/sequence/ p" ./mast_output/mast.xml | grep 'idx="0"' | head -1 | sed 's/.*pos=\"//' | sed 's/\".*//'`
Motif1_map=`sed -n -e "/$REPLY/,/\/sequence/ p" ./mast_output/mast.xml | grep 'idx="0"' | head -1 | sed 's/.*match=\"//' |  sed 's/\".*//' | sed 's/^/\|/' | sed 's/$/\|/'`
#
Motif2_pos=`sed -n -e "/$REPLY/,/\/sequence/ p" ./mast_output/mast.xml | grep 'idx="1"'| head -1 | sed 's/.*pos=\"//' | sed 's/\".*//'`
Motif2_map=`sed -n -e "/$REPLY/,/\/sequence/ p" ./mast_output/mast.xml | grep 'idx="1"' | head -1 | sed 's/.*match=\"//' |  sed 's/\".*//' | sed 's/^/\|/' | sed 's/$/\|/' `
#
echo -e $REPLY"\t"$pval"\t"$eval"\t"$Motif1_pos"\t"$Motif1_map"\t"$Motif2_pos"\t"$Motif2_map | sed -E $'s/\)_/\)\t/'
done < temp_names > temp
#
#
######################################
#leaderless interlude...
######################################
rm "$iso"_leaderless_gene_file 2> /dev/null
rm "$iso"_leaderless_msdin_deduped 2> /dev/null
#
if [[ $runmode =~ (allow_leaderless) ]];then
#okay so in the allowing leaderless, i probably still want to process all fo the ones that that have a leader seperate from those that don't...
#subset those with no MSDIN hit to another leaderless file
awk -F'\t' '$5=="" {print $1"\t"$2"\t"$3"\t"$4"\t"$7"\t"$8}' temp > leaderless_processed_mast
#
 while IFS=$'\t' read -r name frame pvalue evalue motif2_hit motif2_map; do
    Motif2_offset_AA=$(echo "$motif2_map" | sed 's/|//g' | sed 's/+.*//' | wc -c | sed 's/ //g' | awk -v og_offset="$motif2_hit" -v frame="$frame" '{print (og_offset)}')
    Motif2_offset=$(echo "$motif2_map" | sed 's/|//g' | sed 's/+.*//' | wc -c | sed 's/ //g' | awk -v og_offset="$motif2_hit" -v frame="$frame" '{print ((og_offset)*3)+frame}')
Chrm=`echo $name | sed 's/:.*//'`
Og_start=`echo $name | sed 's/.*://' | sed 's/-/ /' | sed -E 's/\(/ /' |sed -E 's/\)//' | awk '{print $1}'`
Og_end=`echo $name | sed 's/.*://' | sed 's/-/ /' | sed -E 's/\(/ /' |sed -E 's/\)//' | awk '{print $2}'`
Orient=`echo $name | sed 's/.*://' | sed 's/-/ /' | sed -E 's/\(/ /' |sed -E 's/\)//' | awk '{print $3}'`
Orient_num=`echo $name | grep +| wc -l |sed 's/ //g' `
seq=$(grep -A 1 "$name"_"$frame" "${iso}_maybe_prot.fasta" | tail -1)
file_name=`echo $name"_"$frame`


    for possible_start_offset in $(seq "$core_min_length" "$core_max_length"); do
      possible_start=$(echo "$Motif2_offset_AA $possible_start_offset" | awk '{print $1-$2}')
      if [ "$possible_start" -gt 0 ]; then
      is_start=$(echo "$seq" | cut -c"$possible_start"-"$possible_start" | awk '{if ($1=="M") {print "1"} else {print "0"}}')
else
#in testing, this sort of issue where the possible start is less than 0 was caused by sequences that were shorter than the possible start offset, this could be caused by genome fragmentation
is_start="0"
fi

      if [ "$is_start" -eq 1 ]; then
        #following is just for testing purposes, no need to clutter the screen
        echo "$name" "$possible_start_offset" "$possible_start" "$is_start"  "$frame"
        

        if [ "$Orient_num" -gt 0 ]; then
          New_start=$(echo "$Og_start" "$possible_start" | awk '{print $1+($2*3)-1 }' | awk -v frame="$frame" '{if (frame=="3") {print} else if (frame=="2") {print $1-1} else if (frame=="1") {print $1-2}}' )
          New_end=$(echo "$New_start"  | awk '{print $1+300}')
          length=$(echo "$name" | sed 's/.*length_//' | sed 's/_.*//' | sed 's/:.*//')
          echo -e "$Chrm\t$New_start\t$New_end\t$file_name\t$length\t$Orient" > processed.bed
          bedtools getfasta -fi "${iso}.fna" -bed processed.bed -s > probably_seq.fasta #2> maybe_seq.err
          trimmed_seq_nuc=$(tail -1 probably_seq.fasta)
          cat probably_seq.fasta | sed '/^>/ s/$/zzz/' | tr -d '\n' | sed $'s/zzz/\t/g' | sed $'s/>/\\\n>/g' | grep . | awk -v iso_file="$iso""_leaderless_msdin_deduped" '{print $1,$2,iso_file}' >> "${iso}_leaderless_gene_file"
          cat processed.bed | awk '{print $1,$2,$3,$1":"$2"-"$3"("$6")",$5,$6}' >> "${iso}_leaderless_msdin_deduped"


        else
          New_end=$(echo "$Og_end" "$possible_start" | awk '{print $1-($2*3)+3}' | awk -v frame="$frame" '{if (frame=="3") {print $1-2} else if (frame=="2") {print $1-1} else if (frame=="1") {print}}')
          New_start=$(echo "$New_end"  | awk '{print $1-300}')
          length=$(echo "$name" | sed 's/.*length_//' | sed 's/_.*//' | sed 's/:.*//')
          echo -e "$Chrm\t$New_start\t$New_end\t$file_name\t$length\t$Orient" > processed.bed
          bedtools getfasta -fi "${iso}.fna" -bed processed.bed -s > probably_seq.fasta #2> maybe_seq.err
          trimmed_seq_nuc=$(tail -1 probably_seq.fasta)
          cat probably_seq.fasta | sed '/^>/ s/$/zzz/' | tr -d '\n' | sed $'s/zzz/\t/g' | sed $'s/>/\\\n>/g' | grep . | awk -v iso_file="$iso""_leaderless_msdin_deduped" '{print $1,$2,iso_file}' >> "${iso}_leaderless_gene_file"
          cat processed.bed | awk '{print $1,$2,$3,$1":"$2"-"$3"("$6")",$5,$6}' >> "${iso}_leaderless_msdin_deduped"

        fi

      fi
    done
  done < leaderless_processed_mast

cat "$iso"_leaderless_gene_file |sort -u > ./deduped_and_gene/"$iso"_leaderless_gene_file
rm "$iso"_leaderless_gene_file
cat "$iso"_leaderless_msdin_deduped | sort -u > ./deduped_and_gene/"$iso"_leaderless_msdin_deduped
rm "$iso"_leaderless_msdin_deduped
#
#
#
######################################
#return to non-leaderless...
######################################
#
#
#
#make sure MSDIN hit is before CVGDD hit (if there are indeed both hits) – reject if no MSDIN hit but not if missing CV hit
awk -F'\t' '$5!="" {print}' temp | awk -F'\t' '{if ($7=="") {print} else if ($5<$7) {print}}'> processed_mast
#
else

#make sure MSDIN hit is before CVGDD hit (if there are indeed both hits) – reject if no MSDIN hit but not if missing CV hit
awk -F'\t' '$5!="" {print}' temp | awk -F'\t' '{if ($7=="") {print} else if ($5<$7) {print}}'> processed_mast
#
#
#the following trims the sequence based on hits above – orienting based on starting M as determined by MSDIN motif hit
while IFS=$'\t' read -r name frame pvalue evalue motif1_hit motif1_map motif2_hit motif2_map;do
#
#this is the in-file name not the name of a file
file_name=`echo $name"_"$frame`
seq=`grep -A 1 $file_name "$iso""_maybe_prot.fasta"| tail -1`
length=`echo $name | sed 's/.*length_//'| sed 's/_.*//'|  sed 's/:.*//'`
Chrm=`echo $name | sed 's/:.*//'`
#
Og_start=`echo $name | sed 's/.*://' | sed 's/-/ /' | sed -E 's/\(/ /' |sed -E 's/\)//' | awk '{print $1}'`
Og_end=`echo $name | sed 's/.*://' | sed 's/-/ /' | sed -E 's/\(/ /' |sed -E 's/\)//' | awk '{print $2}'`
Orient=`echo $name | sed 's/.*://' | sed 's/-/ /' | sed -E 's/\(/ /' |sed -E 's/\)//' | awk '{print $3}'`
Orient_num=`echo $name | grep +| wc -l |sed 's/ //g' `
#
# 
Motif1_offset=`echo $motif1_map | sed 's/\|//g' | sed 's/+.*//'| wc -c | sed 's/ //g' | awk -v og_offset="$motif1_hit" -v frame=$frame '{print ((og_offset)*3)}' | awk -v orientation=$Orient -v frame=$frame '{if (orientation=="+") {print ($1-4)+frame} else {print ($1-4)+frame}}'`
Motif2_offset=`echo $motif2_map | sed 's/\|//g' | sed 's/+.*//'| wc -c | sed 's/ //g' | awk -v og_offset="$motif2_hit" -v frame=$frame '{print ((og_offset)*3)+frame}'`
#
Motif1_offset_AA=` echo $motif1_map | sed 's/\|//g' | sed 's/+.*//'| wc -c | sed 's/ //g' | awk -v og_offset="$motif1_hit" -v frame=$frame '{print (og_offset)}'`
Motif2_offset_AA=` echo $motif2_map | sed 's/\|//g' | sed 's/+.*//'| wc -c | sed 's/ //g' | awk -v og_offset="$motif2_hit" -v frame=$frame '{print (og_offset)}'`
#
Trimmed_Seq=`echo $seq| cut -c"$Motif1_offset_AA"-9999`
#
M_check1=`echo $Motif1_offset_AA | awk '{print $1-1}' | awk '{if ($1=="0") {print "1"} else {print}}'`
M_check2=`echo $Motif1_offset_AA | awk '{print $1}' | awk '{if ($1=="0") {print "1"} else {print}}'`
M_check3=`echo $Motif1_offset_AA | awk '{print $1+1}' | awk '{if ($1=="0") {print "1"} else {print}}'`
#
Is_previous_M=`echo $seq | cut -c"$M_check1"-"$M_check1" |  awk '{if ($1=="M") {print "1"} else {print "0"}}'`
Is_current_M=`echo $seq | cut -c"$M_check2"-"$M_check2" |  awk '{if ($1=="M") {print "1"} else {print "0"}}'`
Is_next_M=`echo $seq | cut -c"$M_check3"-"$M_check3" |  awk '{if ($1=="M") {print "1"} else {print "0"}}'`
#
#process forward and reverse differently…
if [ $Orient_num -gt 0 ];then
#
#
#check if first value is M, if not look at one in, and then one before change the start value accordingly.
New_start_temp=`echo $Og_start|awk -v frame=$frame -v offset="$Motif1_offset" -v check1=$Is_previous_M -v check2=$Is_current_M -v check3=$Is_next_M '{if (check2=="1") {print ($1+offset), "check2"} else if (check3=="1") { print ($1+offset+3),"check3"} else if (check1=="1") {print ($1+offset-3),"check1"} else if (check1=="0" && check2=="0" && check3=="0") {print ($1+offset), "NOCHECK"}}'`
#
New_start=`echo $New_start_temp | awk '{print $1}'`
Check_lvl=` echo $New_start_temp | awk '{print $2}'`
#
#if a nearby M was found then shift the sequence to show that
if [[ $Check_lvl != "check2" && $Check_lvl != "NOCHECK" ]];then
seq_shift=`echo $Check_lvl | sed 's/check//' | awk -v og_offset=$Motif1_offset_AA '{print ($1-2)+og_offset}'`
#
Trimmed_Seq=`echo $seq| cut -c"$seq_shift"-9999`
fi
#
#New_start=`echo $Og_start | awk -v offset="$Motif1_offset" '{print $1+offset}'`
New_end=`echo $New_start| awk '{print $1+300}'`
echo -e $Chrm"\t"$New_start"\t"$New_end"\t"$Trimmed_Seq"__""$Motif1_offset_AA""__""$Check_lvl""__""$Is_previous_M""$Is_current_M""$Is_next_M""__""$Motif2_offset_AA""\t"$length"\t"$Orient | awk -F'\t' '{if ($2<0) {$2="1"} {print $1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6}}' | awk -F'\t' '{if ($3>$5) {$3=$5} {print  $1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6}}'
#
else
#
New_end_temp=`echo $Og_end | awk -v frame=$frame -v offset="$Motif1_offset" -v check1=$Is_previous_M -v check2=$Is_current_M -v check3=$Is_next_M '{if (check2=="1") {print ($1-offset), "check2"} else if (check3=="1") { print ($1-offset-3),"check3"} else if (check1=="1") {print ($1-offset+3),"check1"} else if (check1=="0" && check2=="0" && check3=="0") {print ($1+offset), "NOCHECK"}}'`
#
New_end=`echo $New_end_temp | awk '{print $1}'`
Check_lvl=`echo $New_end_temp | awk '{print $2}'`
#
if [[ $Check_lvl != "check2" && $Check_lvl != "NOCHECK" ]];then
seq_shift=`echo $Check_lvl | sed 's/check//' | awk -v og_offset=$Motif1_offset_AA '{print ($1-2)+og_offset}'`
#
Trimmed_Seq=`echo $seq| cut -c"$seq_shift"-9999`
fi
#
#New_end=`echo $Og_end | awk -v offset="$Motif1_offset" -v frame=$frame '{print $1-offset+3-frame}'`
New_start=`echo $New_end| awk '{print $1-300}'`
#
echo -e $Chrm"\t"$New_start"\t"$New_end"\t"$Trimmed_Seq"__""$Motif1_offset_AA""__""$Check_lvl""__""$Is_previous_M""$Is_current_M""$Is_next_M""__""$Motif2_offset_AA""\t"$length"\t"$Orient | awk -F'\t' '{if ($2<0) {$2="1"} {print $1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6}}' | awk -F'\t' '{if ($3>$5) {$3=$5} {print  $1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6}}'
#
fi
done < processed_mast > temp
#note that processed.bed may contain a truncated version of the protein relative to the bed file.. it just hasn’t been updated..
sort -u -k1,3 -k6,6 temp | grep -v NOCHECK > processed.bed
#
#
#process a bed file for later use in the make_msdin_bed thing…
#
cat processed.bed  | awk '{print $1,$2,$3,$1":"$2"-"$3"("$6")",$5,$6}' > "$iso"_msdin_deduped
#
#
bedtools getfasta -fi "$iso".fna -bed processed.bed -s > probably_seq.fasta 2> maybe_seq.err
#
cat probably_seq.fasta | sed '/^>/ s/$/zzz/' | tr -d '\n' | sed $'s/zzz/\t/g' | sed $'s/>/\\\n>/g' | grep . | awk -v iso_file="$iso""_msdin_deduped" '{print $1,$2,iso_file}'> "$iso"_gene_file
#
#some of these are probably not necessary – 
#The gene_file gets used in the next script, and deduped file gets used in make_msdin_bed_and_parse_motif.sh
#
mv "$iso"_gene_file ./deduped_and_gene/
mv "$iso"_msdin_deduped ./deduped_and_gene/
#
#
fi
#
rm temp_names processed_mast temp processed.bed probably_seq.fasta maybe_seq.err
rm "$iso".fna "$iso".fna.fai "$iso"_maybe_prot.fasta "$iso".fna.gz 2> /dev/null
#
done < name_list
#
rm leaderless_processed_mast
