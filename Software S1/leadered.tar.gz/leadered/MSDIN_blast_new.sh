#!/bin/bash
#########################################################################################
#FUNCTION
#this script will take a genome and find target regions using a set of MSDIN protein sequence it will then translate the target regions
#into all possible reading frames for processing by MSDIN_motif.sh
#
#REQUIRED PROGRAMS
#this script assumes you: have blast, bedtools, and EMBOSS installed and in PATH 
#
#REQUIRED FILES
#this script requires: a single-column list of input names called “name_list” and a library of all known MSDINs you want to reference (use as queries) called "MSDIN_genes_all_lib.txt"  note that these are present in the example input
#
#REQUIRED FORMATING OF INPUT
#genomes should be named “input_name_from_list”.fna.gz (gzipped) and located in the folder path noted above (defined below)
#
#
#MISC
#Please also set variables “Num_threads_for_blast” and “Genome_folder_path” at top of script.
#testing has been one using ncbi accession numbers as names results from other naming schemes may vary
#
#originally developed in OSX environment and tested on linux – see README.
#
#script will self-tidy and while I’ve tried to avoid this, you shouldn’t store any important files in the run directory as they could be remove. All #files that need to be brought in need their paths specified at the top of the script
#
#script outputs a set of proteins that may contain fasta sequences in a folder called ‘putative_msdin_prots’ that it creates
#
#The script renames chromosomes to purge naming schemes that may break the pipeline. To aid in downstream usages, the script will also create a key of #how chromosomes were renamed. This can be useful for later steps if wanting to extract sequences or refer references #in the literature that use the #original naming. Renamed genome files are currently not retained by the script but could be if you remove "$iso".fna from the rm command at the bottom #of the script.
#
###########################################################################################
#
#Variables that may need defining ----------------------------------------------------------------
Num_threads_for_blast="14"
Genome_folder_path="./genomes/"
ReadME="YES"
#------------------------------------------------------------------------------------------------
#
if [ $ReadME != "YES" ];then
echo Please read README before proceeding
exit
fi
#
awk -F'\t' 'NR==1{next} {gsub(/ /,"_",$1); c[$1 FS $3]++; printf(">%s_%s_%d\n%s\n", $1, $3, c[$1 FS $3], $2)}' MSDIN_genes_all_lib.txt > MSDIN.faa
#
mkdir putative_msdin_prots
#loop over isos
while read -r iso;do
#
Current_time=`date +"%T"`
echo ===============================================
echo Beginning msdin_blast of $iso at $Current_time
echo ===============================================
#
#bring in and unzip genome
cp "$Genome_folder_path""$iso".fna.gz .
gunzip "$iso".fna.gz 
#
#deal with the fact that later parts of the program break if you give it a period in name – other characters may also need purging depending on naming
Working_iso=`echo $iso | sed 's/\./_/g'`
#
#rename chromosomes and add chrm length to them…
#first rename file to have the header iso_chrm#
cat "$iso".fna | awk -v iso="$Working_iso" -v chrm="0" '{if ($0 ~ ">") {print ">"iso"_chrm"++chrm} else {print}}' >temp.fna 
#then create a file of chrm lengths to use in renaming where length is added to name
cat temp.fna | awk '$0 ~ ">" {if (NR > 1) {print c;} c=0;printf substr($0,2,100) "\t"; } $0 !~ ">" {c+=length($0);} END { print c; }' | awk '{print ">"$1,">"$1"_""length_"$2}' > temp_chrm_lengths
#
#add lengths to name
awk 'FNR==NR{a[$1]=$2;next} {if ($1 in a){$1=a[$1]}; print $0}' temp_chrm_lengths temp.fna > genome_with_lengths
#
#create key of chrm names – this can be useful later if wanting to extract sequences or refer back to NCBI names
grep '>' "$iso".fna > OG_chrm_names
awk '{print $2}' temp_chrm_lengths  > new_chrm_names
paste OG_chrm_names new_chrm_names > "$iso"_chrm_name_key
rm OG_chrm_names new_chrm_names
#
mv genome_with_lengths "$iso".fna
rm temp.fna temp_chrm_lengths
#
#prepare blast
makeblastdb -dbtype nucl -in "$iso".fna
#
#run blast removing evalues below above 100
tblastn -evalue 100 -query MSDIN.faa -db "$iso".fna -num_threads "$Num_threads_for_blast" -outfmt "6 qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore" > blast_result
#
#go 30bp upstream of blast hit and 300bp downstream of that to grab out full region where MSDIN may be
#process resulting region into a bed file
cat blast_result| awk -F'\t' '{if ($9<$10) {print $0"\t""+"} else {print $0"\t""-"}}' | awk -F'\t' '{if ($13=="+") {print $0"\t"$9-30"\t"$9-30+300} else if ($13=="-") {print $0"\t"$9+30-300"\t"$9+30}}' | awk -F'\t' '{print $1"\t"$2"\t"$14"\t"$15"\t"$13}' | awk '{print $2"\t"$3"\t"$4"\t"$1"__"NR"\t""NA""\t"$5}' > temp_blast.bed
#
#get chrm lengths
awk '{print $1}' temp_blast.bed | sed 's/.*length_//' | sed 's/_cov.*//' > chrm_lengths
#
#the sort makes it so that a certain msdin start location Is only used once no matter how many hits are there.
paste temp_blast.bed chrm_lengths | awk -F'\t' '{print $1"\t"$2"\t"$3"\t"$4"\t"$7"\t"$6}' | awk -F'\t' '{if ($2<0) {$2="1"} {print $1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6}}' | awk -F'\t' '{if ($3>$5) {$3=$5} {print  $1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6}}' | sort -u -k1,3 > blast.bed
#
#
#use bedfile to obtain putative-hit fasta sequences, ignoring the errors into the “maybe_seq.err” file
bedtools getfasta -fi "$iso".fna -bed blast.bed -s > maybe_seq.fasta 2> maybe_seq.err
#
#first fix up the fasta file so that transeq will be okay with it…
cat maybe_seq.fasta | sed 's/:/__/' > temp
#
#then translate into all reading frames
transeq -sequence temp -outseq temp_prot.fasta -frame F
#
#place each sequence onto its own line
cat temp_prot.fasta | sed 's/__/:/' | sed '/^>/ s/$/zzz/' |tr -d '\n' | sed $'s/zzz/\\\n/g'  | sed $'s/>/\\\n>/g' | grep . > "$iso"_maybe_prot.fasta 
#
#tidy
mv "$iso"_maybe_prot.fasta  ./putative_msdin_prots/
mv "$iso"_chrm_name_key ./putative_msdin_prots/
#
rm "$iso".fna "$iso".fna.fai "$iso".fna.ndb "$iso".fna.nhr "$iso".fna.nin "$iso".fna.not "$iso".fna.nsq "$iso".fna.ntf "$iso".fna.nto "$iso".fna.njs 
rm maybe_seq.err maybe_seq.fasta temp_prot.fasta blast_result chrm_lengths temp blast.bed temp_blast.bed
#
done <  name_list
rm -r mast_output/
rm MSDIN.faa 
