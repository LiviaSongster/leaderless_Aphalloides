#!/bin/bash
#########################################################################################
#FUNCTION
#This script will take the processed output of make_msdin_bed_and_parse_motif.sh and score the resulting possible MSDINs that were identified
# requires and updates the parsed_best_msdin and processed_best_msdin.bed files generated in previous
#the script will assign a single point for each of the following:
#one point per match for the exact motif “CVGDDV”
#thirty points if the core region has been identified previously
#one point each for the final L and C residues.
#one point if the length of the follower is between 16 and 18 inclusive
#one point if the leader ends in a P
#
#REQUIRED FILES
#script assumes that there is a file called “MSDIN_genes_all_lib.txt” that is tab delimited text with the columns: species, msdin_seq, toxin (if #known), msdin_leader_seq,msdin_core_seq,msdin_follower_seq,sorce_of_info – really its only important that the fifth column be the core sequence
#
#REQUIRED INPUT
#script assumes output of previous script was output correctly and into the default folder
#
#OUTPUT NOTES
#the script will generate and output the following files into 
#a folder called “final_msdin”
#
#the script will output:
#
#parsed_best_msdin_prot_with_scores – all of the scored MSDINs (just the prots). This file’s columns include – note some column names are not defined #here because they’re not relevant to end users: 1) a name that includes the original name of the input genome (access for NCBI). 3) a naming scheme #that refers to where the MSDIN was found in the genome and a code that indicates how to process it. These names can be used to reference other files. 
# 4) the protein leader sequence
# 5) the protein core sequence
# 6) the protein follower sequence
# 7) the full MSDIn sequence
#
#multiple_msdin_same_locus – a list of msdin loci that contain multiple of the same highest score msdins (this is rare and may be empty)
#
#one_per_locus_high_scoring – a subset of msdins from parsed_best_msdin_prot_with_scores where only the highest scoring msdin per locus is kept. If #multiple msdin have the same score at a given locus (rare) then one is chosen randomly – in my experience, such MSDINs do not pass final filtering
#
# one_per_locus_high_scoring_with_scores
#same information as one_per_locus_high_scoring but additionally a summed score is indicated in the last column
#
# one_per_locus_high_scoring_with_scores
#same information as one_per_locus_high_scoring_with_scores but has been filtered by score based on user-defined inputs
#
#parsed_best_msdin_final this file contains very similar information as parsed_best_msdin_prot_with_scores and one_per_locus_high_scoring but will also #contain the multiple highest scoring at the same locus – it also includes nucleotide info not just amino acid in a format similar to that of #parsed_best_msdin_prot_with_scores
#
#
#processed_best_msdin_final.bed this contains a bed file for all of the ones from one_per_locus_high_scoring naming in this file corresponds to that in #the third and fourth column of the one_per_locus_high_scoring file. Remember that chromosomes have been renamed, and that a key to the renaming scheme #is available in the putative_msdin_prots folder created by the first script.
#
#
#########################################################################################
#
##Variables that may need defining ----------------------------------------------------------------
Path_to_parsed_best_msdin="./processed_msdin/"
Path_to_known_msdin_lib="./"
Score_to_filter_to="5"
#----------------------------------------------------------------
#
awk '$2=="PROT" {print $1,$7}' "$Path_to_parsed_best_msdin"parsed_best_msdin | sort -u > temp
#for testing
#awk '$2=="PROT" {print $1,$7}' "$Path_to_parsed_best_msdin"parsed_best_msdin | sort -u  | grep GCA_023014455.1_ASM2301445v1_genomic_msdin_deduped > temp
Count_of_msdin_to_score=`cat temp | wc -l | sed 's/ //g'`
COUNTER="1"
#
rm parsed_best_msdin_prot_with_scores
while read iso msdin;do
#
#
echo ------------------------------------------------- 
echo SCORING msdin $COUNTER of $Count_of_msdin_to_score
echo -------------------------------------------------
#
COUNTER=$[COUNTER + 1]
#
awk -v iso="$iso" -v msdin="$msdin" '$1==iso && $7==msdin {print}' "$Path_to_parsed_best_msdin"parsed_best_msdin > current_msdin
#
Current_count=`cat current_msdin | wc -l | sed 's/ //g'`
#
if [ $Current_count -gt 1 ];then
#
#lets score the different possible locations of the core and print them out..
#
while read -r name prot contig leader core follower full;do
#
Pos_1=`echo $follower | sed 's/./& /g' | awk '{if ($1=="C") {print "1"} else {print "0"} }'`
Pos_2=`echo $follower | sed 's/./& /g' | awk '{if ($2=="V") {print "1"} else {print "0"} }'`
Pos_3=`echo $follower | sed 's/./& /g' | awk '{if ($3=="G") {print "1"} else {print "0"} }'`
Pos_4=`echo $follower | sed 's/./& /g' | awk '{if ($4=="D") {print "1"} else {print "0"} }'`
Pos_5=`echo $follower | sed 's/./& /g' | awk '{if ($5=="D") {print "1"} else {print "0"} }'`
Pos_6=`echo $follower | sed 's/./& /g' | awk '{if ($6=="V") {print "1"} else {print "0"} }'`
#
Canon=`echo $contig | grep _NC | wc -l | sed 's/ //g'`
#
#lets score if the MSDIN is known..
cat "$Path_to_known_msdin_lib"MSDIN_genes_all_lib.txt | awk -F'\t' 'NR>1 {print $5}' | sort -u  > all_known_msdin
scoreKNOWN=`grep -w $core all_known_msdin| head -1 | wc -l | sed 's/ //g' | awk '{print $1*30}'`
#
#lets score the end of the protein too..
#
PosC=`echo $follower | sed 's/./& /g' | awk '{if ($(NF-1)=="C") {print "1"} else {print "0"} }'`
PosL=`echo $follower | sed 's/./& /g' | awk '{if ($(NF-2)=="L") {print "1"} else {print "0"} }'`
#
scoreLC=`echo -e "$PosL""\n""$PosC"| awk '{sum+=$1} END {print sum}'`
score=`echo -e "$Pos_1""\n""$Pos_2""\n""$Pos_3""\n""$Pos_4""\n""$Pos_5""\n""$Pos_6" | awk '{sum+=$1} END {print sum}'`
#
score_follower_length=` echo $follower |sed 's/\*//'| awk '{print length}'|awk '{if ($1 >= 16 && $1<=18) {print "1"} else {print "0"}}' `
#
#okay and lets add a score for the leader too…
score_leader=`echo $leader | sed 's/./& /g' | awk '{if ($(NF)=="P") {print "1"} else {print "0"} }'`
#
score_core_proline=`echo $core | sed 's/./& /g' | awk '{if ($(NF)=="P") {print "1"} else {print "0"} }'`

echo $name $prot $contig $leader $core $follower $full $score $scoreLC $score_leader $score_core_proline $score_follower_length $scoreKNOWN "contested" $Canon | awk '{print $0,($8+$9+$10+$11+$12+$13+$15)}' >> parsed_best_msdin_prot_with_scores
done < <(cat current_msdin)
#
else
#
while read -r name prot contig leader core follower full;do
#
Pos_1=`echo $follower | sed 's/./& /g' | awk '{if ($1=="C") {print "1"} else {print "0"} }'`
Pos_2=`echo $follower | sed 's/./& /g' | awk '{if ($2=="V") {print "1"} else {print "0"} }'`
Pos_3=`echo $follower | sed 's/./& /g' | awk '{if ($3=="G") {print "1"} else {print "0"} }'`
Pos_4=`echo $follower | sed 's/./& /g' | awk '{if ($4=="D") {print "1"} else {print "0"} }'`
Pos_5=`echo $follower | sed 's/./& /g' | awk '{if ($5=="D") {print "1"} else {print "0"} }'`
Pos_6=`echo $follower | sed 's/./& /g' | awk '{if ($6=="V") {print "1"} else {print "0"} }'`
#
Canon=`echo $contig | grep _NC | wc -l | sed 's/ //g'`
#
#lets score if the MSDIN is known..
cat "$Path_to_known_msdin_lib"MSDIN_genes_all_lib.txt | awk -F'\t' 'NR>1 {print $5}' | sort -u  > all_known_msdin
scoreKNOWN=`grep -w $core all_known_msdin| head -1 | wc -l | sed 's/ //g' | awk '{print $1*30}' `
#
#lets score the end of the protein too..
#
PosC=`echo $follower | sed 's/./& /g' | awk '{if ($(NF-1)=="C") {print "1"} else {print "0"} }'`
PosL=`echo $follower | sed 's/./& /g' | awk '{if ($(NF-2)=="L") {print "1"} else {print "0"} }'`
#
scoreLC=`echo -e "$PosL""\n""$PosC"| awk '{sum+=$1} END {print sum}'`
score=`echo -e "$Pos_1""\n""$Pos_2""\n""$Pos_3""\n""$Pos_4""\n""$Pos_5""\n""$Pos_6" | awk '{sum+=$1} END {print sum}'`
#
#lets add a score for the length of the follower… if it falls in the normal, inclusive, range of 16-18 (without stop) then give it a point if not then #none
#
score_follower_length=` echo $follower | sed 's/\*//'| awk '{print length}'|awk '{if ($1 >= 16 && $1<=18) {print "1"} else {print "0"}}' `
#
#okay and lets add a score for the leader too…
score_leader=`echo $leader | sed 's/./& /g' | awk '{if ($(NF)=="P") {print "1"} else {print "0"} }'`
#
score_core_proline=`echo $core | sed 's/./& /g' | awk '{if ($(NF)=="P") {print "1"} else {print "0"} }'`
#
echo $name $prot $contig $leader $core $follower $full $score $scoreLC $score_leader $score_core_proline $score_follower_length $scoreKNOWN "uncontested" $Canon | awk '{print $0,($8+$9+$10+$11+$12+$13+$15)}' >> parsed_best_msdin_prot_with_scores
done < <(cat current_msdin)
#
fi
#
done < <(cat temp) 
rm temp current_msdin
#
#
#
echo ------------------------------------------------- 
echo filtering scores by locus 
echo -------------------------------------------------
#

#column 11 is now
#cat parsed_best_msdin_prot_with_scores  | awk '{print $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16}' | column -t | sort -k16,16nr | sed 's/_z_/ _z_/' | awk '{a[$3]=$17>a[$3]?$17:a[$3];b[$3]=$17==a[$3]?b[$3] $0 ORS:b[$3]} END{for(i in b)printf b[i]}'| sort -k3,3 



#filter high scoring ones at same locus..
#cat parsed_best_msdin_prot_with_scores | sed 's/_z_/ _z_/' | sort -k3,3 -k13,13nr -k11,11nr -k10,10nr -k9,9nr -k12,12nr  > temp_scores
# so this old version is priortizing $scoreKNOWN > score_leader > scoreLC > score(cvgddv) > score_follower_length -- it is not just taking the highest score
# so in adding the new variable $score_core_proline as the 11th column, i want the prioritization to look like...
#$scoreKNOWN > score_leader > scoreLC > score_core_poline>score(cvgddv) > score_follower_length > score_canon ... so that would be...
#$name $prot $contig $leader $core $follower $full $score $scoreLC $score_leader $score_core_proline $score_follower_length $scoreKNOWN
#but actually with the sed command we're expanding the columns to:
#$name $prot $contig $contig2 $leader $core $follower $full $score $scoreLC $score_leader $score_core_proline $score_follower_length $scoreKNOWN  "uncontested" $Canon
cat parsed_best_msdin_prot_with_scores | sed 's/_z_/ _z_/' | sort -k3,3 -k14,14nr -k11,11nr -k10,10nr -k12,12nr -k9,9nr -k13,13nr -k16,16 > temp_scores
cat temp_scores | sort -u -k3,3 | awk '{print $3,$9,$10,$11,$13,$14,$12,$16}' > temp_loop
#
#obtain highest scores at each locus
#score 1 is CVGDDV score
#score 2 is the LC score
#score 3 is the leader score
#score 4 is based on follower length
#score 5 is based on if the msdin is known..
#score 6 is now the core proline
#score 7 is the canonical intron
while read locus score1 score2 score3 score4 score5 score6 score7;do
#take the line(s) that has the high-scoring scores for that locus
awk -v locus="$locus" -v score1="$score1" -v score2="$score2" -v score3="$score3" -v score4="$score4" -v score5="$score5" -v score6="$score6" -v score7="$score7" '$3==locus && $9==score1 && $10==score2 && $11==score3 && $13==score4 && $14==score5 && $12==score6 && $16==score7 {print}' temp_scores 
done < temp_loop >high_scoring
rm temp_scores temp_loop 
#
#
#output those that have multiple identical scores at same locus:
awk '{c[$3]++}END{ for (i in c) print i,c[i]}' high_scoring | sort -k2,2nr | awk '$2>1 {print}' > multiple_msdin_same_locus
#
#randomly select one per locus from those that overlap…
shuf high_scoring | sort -u -k3,3 > one_per_locus_high_scoring
#
#
#filter parsed and bed file based on filtering from scoring:
#
#
echo -------------------------------------------------------------------------------- 
echo outputting final parsed and bed file based on highest scoring msdin per locus
echo --------------------------------------------------------------------------------
#
#lets deal with the parsed file first 
while read -r name prot contig stop_search leader core follower full follower_start_score follower_end_score contested canon;do
#
Combo_name=`echo "$contig""$stop_search"`
#
awk -v combo="$Combo_name" '$3==combo {print}' "$Path_to_parsed_best_msdin"parsed_best_msdin 
done <  high_scoring > parsed_best_msdin_final
#
#
#and now the bed file..
#
while read -r name prot contig stop_search leader core follower full follower_start_score follower_end_score contested canon;do
#
Combo_name_exon1=`echo "exon1_z_""$contig""__""$name""$stop_search"`
Combo_name_intron1=`echo "intron1_z_""$contig""__""$name""$stop_search"`
Combo_name_exon2=`echo "exon2_z_""$contig""__""$name""$stop_search"`
#
awk -v combo="$Combo_name_exon1" '$4==combo {print}' "$Path_to_parsed_best_msdin"processed_best_msdin.bed
awk -v combo="$Combo_name_exon2" '$4==combo {print}' "$Path_to_parsed_best_msdin"processed_best_msdin.bed
awk -v combo="$Combo_name_intron1" '$4==combo {print}' "$Path_to_parsed_best_msdin"processed_best_msdin.bed
#
done < one_per_locus_high_scoring > processed_best_msdin_final.bed
#
#This scoring for final filtering does not account for the canonical intron as that seems to be not be a defining character
#in this revamped version, it is now ignoring the proline score for the end of the core.
#note sum of scores has already been added above when first making hte one_per_locus_high_scoring file
#note that the original cutoff value for the scoring does not account for the addition of the proline core here.
cat one_per_locus_high_scoring  | sort -k1,1 -k17,17nr > one_per_locus_high_scoring_with_scores
#
awk -v score="$Score_to_filter_to" '$17>=score {print}' one_per_locus_high_scoring_with_scores  > one_per_locus_high_scoring_with_scores_filtered
#
mkdir final_msdin
mv parsed_best_msdin_prot_with_scores ./final_msdin
mv  processed_best_msdin_final.bed ./final_msdin/
mv  parsed_best_msdin_final ./final_msdin/
mv one_per_locus_high_scoring  ./final_msdin/
mv multiple_msdin_same_locus ./final_msdin/
#
mv one_per_locus_high_scoring_with_scores ./final_msdin/
mv one_per_locus_high_scoring_with_scores_filtered ./final_msdin/
#
#
rm high_scoring
